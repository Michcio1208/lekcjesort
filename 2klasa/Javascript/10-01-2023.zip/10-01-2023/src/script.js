/*console.log("tekst w przegladarce wow")
let a=10
let b=20
let c=prompt("podaj liczbe pls")
console.log("podales liczbe thx "+c)
if(a>b){
  console.log("a>b")
}
else{
  console.log("a nie jest wieksze od b")
}

//delta
let a=parseInt(prompt("podaj liczbe a pls"))
let b=parseInt(prompt("podaj liczbe b pls"))
let c=parseInt(prompt("podaj liczbe c pls"))
let d=(b*b)-(4*a*c)
if(d==0)
{
  console.log("1 rozw")
}
else if(d<0)
{
  console.log("nie ma rozw")
}
else
{
  console.log("sa 2 rozw")
}*/
//bmi calc
let m=parseInt(prompt("podaj  mase w kg pls"))
let w=parseInt(prompt("podaj  wzrost w metrach pls"))
let bmi=m/(w*w)

if(bmi<18.5){
  console.log("you're underweight")
}
if(bmi<18.5){
  console.log("")
}