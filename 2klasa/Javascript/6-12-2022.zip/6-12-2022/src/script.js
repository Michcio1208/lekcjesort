/*console.log("2a") //zmienne
let name=prompt("Podaj imie: ")
let number=100
console.log("twoje imie to: " + name)
console.log(number)

let n=parseInt(prompt("podaj pierwsza zmienna: ")) //dzialanie ,dodawanie jest dziwne
let n1=parseInt(prompt("podaj druga zmienna: "))
console.log(`suma to:    ${n+n1}` ) // ` obok tab'a
console.log("suma to:  " + n-n1 )
console.log("suma to:  " + n*n1 )
console.log("suma to:  " + n/n1 )*/

let a=parseInt(prompt("podaj pierwsza podstawe: ")) //pole trapezu
let b=parseInt(prompt("podaj druga podstawe: "))
let h=parseInt(prompt("podaj wysokosc: "))
console.log(`pole trapezu to ${(a+b)*h/2}`)